# encoding: utf-8
"""
Procesa todos los municipios de la provincia de Girona:
- Descarga contratos adjudicados/formalizados de PSCP (dades obertes de
  la Generalitat de Catalunya, dataset ybgg-dgi6 -- ver Fase 0/1)
- Busca directivos de empresas adjudicatarias (mismo Registro Mercantil
  nacional que ya usa Murcia, sin cambios)
- Guarda en SQLite (cache.db) con provincia="girona"
- Genera resumen_girona.txt

Nota: la UI (render_html, municipio_valido, botón "Actualizar", enlace
"Perfil PLACE") sigue acoplada solo a Murcia -- eso es la Fase 4,
todavía no implementada. Ejecutar este script ya deja los datos
correctos y aislados en cache.db (provincia="girona"), pero navegar a
/?muni=<municipio de Girona> en la web actual mostrará un enlace de
"Perfil PLACE" vacío y el botón "Actualizar" no hará nada, hasta que se
generalicen esas rutas.
"""
import sys, os, time
sys.stdout.reconfigure(encoding='utf-8', errors='replace')
sys.path.insert(0, os.path.dirname(__file__))

from app import (
    MUNICIPIOS_GIRONA, BASE_DIR,
    _db_init, _inicializar_datos, _datos_memoria, _datos_lock,
    _db_set_municipio, normalizar,
    buscar_en_pscp, buscar_directivo, analizar_riesgo, fmt_eur,
    _limpiar_cache_negativos, _dir_cache_get,
)

# ─── Init ────────────────────────────────────────────────────────────────────
_db_init()
_inicializar_datos()

# Limpiar cache negativo para reutilizar directivos ya encontrados (la
# caché de directivos es compartida con Murcia: mismo BORME nacional)
_limpiar_cache_negativos()

# ─── Municipios de Girona ya procesados hoy ──────────────────────────────────
SEGUNDOS_RECIENTES = 12 * 3600  # si tiene datos de las últimas 12h, saltar
muni_ya_procesados = set()
with _datos_lock:
    for d in _datos_memoria:
        if d.get("provincia") != "girona":
            continue
        muni = d.get("municipio", "")
        ts = d.get("timestamp", 0)
        if muni and (time.time() - ts) < SEGUNDOS_RECIENTES and d.get("total_contratos", 0) >= 0:
            muni_ya_procesados.add(muni)

print(f"Municipios de Girona ya con datos recientes (se actualizarán igual): {len(muni_ya_procesados)}")
print(f"Total municipios a procesar: {len(MUNICIPIOS_GIRONA)}\n")


# ─── Función principal por municipio ─────────────────────────────────────────
def procesar_municipio(municipio, idx, total):
    t0 = time.time()
    print(f"\n{'─'*60}")
    print(f"[{idx}/{total}] {municipio.upper()}")

    try:
        contratos = buscar_en_pscp(municipio)
        print(f"  PSCP: {len(contratos)} contratos")
    except Exception as e:
        print(f"  PSCP: error ({type(e).__name__})")
        contratos = []

    # Deduplicar (defensivo -- buscar_en_pscp ya deduplica Adjudicació/
    # Formalització internamente, esto es la misma red de seguridad por
    # url/título que usa procesar_todos_murcia.py)
    vistos = set()
    unicos = []
    for c in contratos:
        key = c.get("url") or c.get("titulo", "")[:80]
        if key and key not in vistos:
            vistos.add(key)
            unicos.append(c)
    contratos = unicos
    print(f"  Contratos únicos: {len(contratos)}")

    # Directivos (idéntico al pipeline de Murcia: mismo Registro Mercantil)
    emp_nif = {}
    for c in contratos:
        emp = c.get("empresa", "")
        if emp and emp != "No localizada" and emp not in emp_nif:
            emp_nif[emp] = c.get("nif", "")

    n_encontrados = 0
    n_buscados = 0
    for emp, nif in emp_nif.items():
        nombre, cargo = buscar_directivo(emp, nif)
        if nombre:
            n_encontrados += 1
        n_buscados += 1
        time.sleep(0.3)  # delay cortés entre peticiones (igual que Murcia)

    # Aplicar a contratos
    directivos_cache = {}
    for emp, nif in emp_nif.items():
        n, c = _dir_cache_get(emp, nif)
        directivos_cache[emp] = (n or "", c or "")

    for c in contratos:
        emp = c.get("empresa", "")
        if emp in directivos_cache:
            c["directivo"], c["cargo"] = directivos_cache[emp]

    pct = int(100 * n_encontrados / max(1, len(emp_nif))) if emp_nif else 0
    print(f"  Directivos: {n_encontrados}/{len(emp_nif)} ({pct}%)")

    # Guardar
    alertas = analizar_riesgo(contratos)
    importe_total = sum(c.get("importe_num", 0) for c in contratos)

    resultado = {
        "municipio":       municipio,
        "organismo":       f"Ajuntament de {municipio}",
        "total_contratos": len(contratos),
        "contratos":       contratos,
        "alertas":         alertas,
        # PSCP no tiene un "perfil de contratante" equivalente al de PLACE.
        # Se deja vacío a propósito (en vez de omitir la clave) para que
        # render_html, al hacer d.get("place_profile", place_profile_url(...)),
        # no caiga en el fallback de Murcia y muestre un enlace incorrecto.
        "place_profile":   "",
        "timestamp":       time.time(),
    }

    with _datos_lock:
        _datos_memoria[:] = [
            d for d in _datos_memoria
            if normalizar(d.get("municipio","")) != normalizar(municipio)
        ]
        _datos_memoria.append(resultado)
    _db_set_municipio(municipio, resultado, provincia="girona")

    elapsed = time.time() - t0
    print(f"  [OK {elapsed:.0f}s] contratos={len(contratos)} importe={fmt_eur(str(importe_total))} dir={n_encontrados}/{len(emp_nif)}({pct}%)")

    return {
        "municipio":   municipio,
        "contratos":   len(contratos),
        "importe":     importe_total,
        "empresas":    len(emp_nif),
        "directivos":  n_encontrados,
        "pct":         pct,
        "elapsed":     elapsed,
        "error":       None,
    }


# ─── Bucle principal ──────────────────────────────────────────────────────────
total = len(MUNICIPIOS_GIRONA)
resultados = []
fallos = []

t_global = time.time()

for idx, municipio in enumerate(MUNICIPIOS_GIRONA, 1):
    for intento in range(3):
        try:
            r = procesar_municipio(municipio, idx, total)
            resultados.append(r)
            break
        except Exception as e:
            print(f"  ERROR intento {intento+1}/3: {type(e).__name__}: {e}")
            if intento < 2:
                time.sleep(5)
            else:
                print(f"  FALLO DEFINITIVO: {municipio}")
                fallos.append({"municipio": municipio, "error": str(e)})
                resultados.append({
                    "municipio": municipio, "contratos": 0, "importe": 0,
                    "empresas": 0, "directivos": 0, "pct": 0,
                    "elapsed": 0, "error": str(e),
                })

# ─── Resumen ──────────────────────────────────────────────────────────────────
elapsed_total = time.time() - t_global

print(f"\n{'='*65}")
print(f"RESUMEN FINAL — {len(resultados)} municipios procesados en {elapsed_total/60:.1f} min")
print(f"{'='*65}")
print(f"{'Municipio':<40} {'Contratos':>10} {'Importe':>18} {'Directivos':>12}")
print(f"{'─'*40} {'─'*10} {'─'*18} {'─'*12}")

total_contratos = 0
total_importe = 0
total_dir = 0
total_emp = 0

for r in resultados:
    muni = r["municipio"]
    nc = r["contratos"]
    imp = r["importe"]
    nd = r["directivos"]
    ne = r["empresas"]
    pct = r["pct"]
    err = r.get("error")

    total_contratos += nc
    total_importe += imp
    total_dir += nd
    total_emp += ne

    imp_str = fmt_eur(str(imp)) if imp else "—"
    dir_str = f"{nd}/{ne} ({pct}%)" if ne else "—"
    err_str = f" [ERROR: {err[:30]}]" if err else ""
    print(f"  {muni:<38} {nc:>10} {imp_str:>18} {dir_str:>12}{err_str}")

print(f"{'─'*40} {'─'*10} {'─'*18} {'─'*12}")
pct_global = int(100*total_dir/max(1,total_emp))
print(f"  {'TOTAL':<38} {total_contratos:>10} {fmt_eur(str(total_importe)):>18} {total_dir}/{total_emp} ({pct_global}%)")

if fallos:
    print(f"\nMUNICIPIOS CON FALLO ({len(fallos)}):")
    for f in fallos:
        print(f"  - {f['municipio']}: {f['error'][:60]}")

# ─── Guardar resumen_girona.txt ──────────────────────────────────────────────
resumen_path = os.path.join(BASE_DIR, "..", "resumen_girona.txt")
with open(resumen_path, "w", encoding="utf-8") as f:
    f.write(f"RESUMEN — CONTRATOS PÚBLICOS PROVINCIA DE GIRONA\n")
    f.write(f"Generado: {time.strftime('%Y-%m-%d %H:%M')}\n")
    f.write(f"Duración total: {elapsed_total/60:.1f} min\n\n")
    f.write(f"{'Municipio':<40} {'Contratos':>10} {'Importe (EUR)':>20} {'Directivos':>14}\n")
    f.write(f"{'─'*84}\n")
    for r in resultados:
        imp_str = fmt_eur(str(r['importe'])) if r['importe'] else "—"
        dir_str = f"{r['directivos']}/{r['empresas']} ({r['pct']}%)"
        err = f"  ERROR: {r['error'][:30]}" if r.get("error") else ""
        f.write(f"  {r['municipio']:<38} {r['contratos']:>10} {imp_str:>20} {dir_str:>14}{err}\n")
    f.write(f"{'─'*84}\n")
    f.write(f"  {'TOTAL':<38} {total_contratos:>10} {fmt_eur(str(total_importe)):>20} {total_dir}/{total_emp} ({pct_global}%)\n")
    if fallos:
        f.write(f"\nFALLOS:\n")
        for fl in fallos:
            f.write(f"  - {fl['municipio']}: {fl['error']}\n")

print(f"\nResumen guardado en: {resumen_path}")
print("Proceso completado. Reinicia el servidor para ver todos los municipios.")
